const nav = document.querySelector('.nav');
const toggle = document.querySelector('.nav__toggle');
const navLinks = document.querySelectorAll('.nav__link');

if (toggle) {
    toggle.addEventListener('click', () => {
        nav.classList.toggle('is-open');
    });
}

navLinks.forEach((link) => {
    link.addEventListener('click', () => {
        nav.classList.remove('is-open');
    });
});
